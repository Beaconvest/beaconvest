from fastapi import APIRouter
import requests

router = APIRouter(prefix="/stocks", tags=["stocks"])

@router.get("/price")
def get_stock_price(symbol: str):
    url = f"https://cloud.iexapis.com/stable/stock/{symbol}/quote?token=YOUR_TOKEN"
    response = requests.get(url)
    return response.json()