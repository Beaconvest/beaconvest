# 📊 BeaconVest

> Real-time multi-asset investment analysis with live data, guidance, and actionable insights.

---

### 🔍 Features

- ✅ **Live Stock Data** (via IEX Cloud)
- ✅ **Live Crypto Data** (via CoinGecko)
- ✅ **Streamlit UI** with tabbed view and real-time inputs
- ✅ **FastAPI Backend** with modular routes
- ✅ **Minimal lag**, sharp and confident analytics

---

### 🚀 How to Run

#### 1. Backend (FastAPI)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

#### 2. Frontend (Streamlit)

```bash
cd frontend
pip install -r requirements.txt
streamlit run app.py
```

---

### 🧠 API Providers

- [IEX Cloud](https://iexcloud.io)
- [CoinGecko](https://coingecko.com)

---

### 📌 Future Additions

- Charting with Plotly or TradingView
- Daily pick engine with email alerts
- Strategy picker
- Portfolio tracking

---

**License**: MIT

Made with ❤️ by Kristopher Scrivens & ChatGPT (OpenAI)