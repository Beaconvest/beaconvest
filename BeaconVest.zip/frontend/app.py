import streamlit as st
import requests

st.title("BeaconVest")

tab1, tab2 = st.tabs(["Stocks", "Crypto"])

with tab1:
    symbol = st.text_input("Enter stock symbol", "AAPL")
    if st.button("Get Stock Price"):
        response = requests.get(f"http://localhost:8000/stocks/price?symbol={symbol}")
        st.json(response.json())

with tab2:
    coin = st.text_input("Enter crypto ID", "bitcoin")
    if st.button("Get Crypto Price"):
        response = requests.get(f"http://localhost:8000/crypto/price?coin_id={coin}")
        st.json(response.json())